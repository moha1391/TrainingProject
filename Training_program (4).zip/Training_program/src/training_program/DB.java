/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package training_program;

/**
 *
 * @author Mohammed
 */
import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Mohammed
 */


/**
 * This class is used to handle the database connection
 * @author moham15
 */
public class DB {

    /**
     *
     * @return
     */
    public static Connection getConnection()
    {
        Connection conn = null;
        try
        {
            
            
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/database1;create=true","user:moha1391","password:qxy65tpa");
            
           
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            
        }
        return conn;
        }
  public static void releaseConnection(Connection conn)
  {
      try{
          conn.close();
      }
      catch (Exception e)
      { System.err.println(e);}
  }

}
