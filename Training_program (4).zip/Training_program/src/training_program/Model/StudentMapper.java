/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package training_program.Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import training_program.DB;

/**
 *
 * @author Mohammed
 */
public class StudentMapper {

    public StudentMapper() {

    }

    public ArrayList<Student> getAllStudents() {
        ArrayList<Student> students = new ArrayList<Student>();

        Connection con = null;
        ResultSet result = null;

        try {
            con = DB.getConnection();
            Statement st = con.createStatement();
            //result = st.executeQuery("SELECT * FROM customer1");
            result = st.executeQuery("SELECT * FROM student");
            while (result.next()) {
                int id = result.getInt(1);

                String fName = result.getString(2);
                String lName = result.getString(3);
                String address = result.getString(4);
                String phone = result.getString(5);
                String email = result.getString(6);
                String birthday = result.getString(7);
                students.add(new Student(id, fName, lName, address, phone, email, birthday));
            }
        } catch (SQLException e) {
        } finally {
            DB.releaseConnection(con);
        }
        return students;
    }

    public Student getStudent(String searchname) {

        Student s = null;
        Connection con = null;
        ResultSet result = null;

        try {
            con = DB.getConnection();
            PreparedStatement st = con.prepareStatement("SELECT *" + "FROM student" + "WHERE lName= ?");
            st.setString(3, searchname);
            result = st.executeQuery();

            if (result.next()) {
                int id = result.getInt(1);

                String fName = result.getString(2);
                String lName = result.getString(3);
                String address = result.getString(4);
                String phone = result.getString(5);
                String email = result.getString(6);
                String birthday = result.getString(7);

                s = new Student(id, fName, lName, address, phone, email, birthday);

            }

        } catch (SQLException e) {

        } finally {
            DB.releaseConnection(con);
        }

        return s;
    }

    public void insertNewStudent(Student s) {
        Connection con = null;

        try {
            con = DB.getConnection();
            PreparedStatement st = con.prepareStatement("INSERT INTO student (fName, lName, address, phone, email,birthday) values(?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);

            st.setString(1, s.getFirstName());
            st.setString(2, s.getLastName());
            st.setString(3, s.getEmail());
            st.setString(4, s.getPhone());
            st.setString(5, s.getBirthday());

            st.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            DB.releaseConnection(con);
        }
    }

    public void deleteStudent(int id) {
        Connection con = null;

        try {
            con = DB.getConnection();
            PreparedStatement st = con.prepareStatement("DELETE FROM student WHERE id = ? ");
            st.setInt(1, id);
            st.executeUpdate();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        } finally {
            DB.releaseConnection(con);
        }
    }

    public void updateStudent(Student s) {
        Connection con = null;
        try {
            con = DB.getConnection();
            PreparedStatement st = con.prepareStatement("UPDATE student "
                    + "fName= ?, lName=?, address=?, phone=?, email=?,birthday=?"
                    + "WHERE id = ?");

            st.setString(1, s.getFirstName());
            st.setString(2, s.getLastName());
            st.setString(3, s.getEmail());
            st.setString(4, s.getPhone());
            st.setString(5, s.getBirthday());
            st.setInt(6, s.getId());

            st.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);

        } finally {
            DB.releaseConnection(con);
        }
    }

}
