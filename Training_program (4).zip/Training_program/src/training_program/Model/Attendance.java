/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package training_program.Model;

/**
 *
 * @author Mohammed
 */
public class Attendance {
    
    private String missingDate;
    private String Reason;

    /**
     * Get the value of Reason
     *
     * @return the value of Reason
     */
    public String getReason() {
        return Reason;
    }

    /**
     * Set the value of Reason
     *
     * @param Reason new value of Reason
     */
    public void setReason(String Reason) {
        this.Reason = Reason;
    }


    /**
     * Get the value of missingDate
     *
     * @return the value of missingDate
     */
    public String getMissingDate() {
        return missingDate;
    }

    /**
     * Set the value of missingDate
     *
     * @param missingDate new value of missingDate
     */
    public void setMissingDate(String missingDate) {
        this.missingDate = missingDate;
    }

}
