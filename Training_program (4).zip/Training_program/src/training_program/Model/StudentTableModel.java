/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package training_program.Model;

import java.util.ArrayList;

/**
 *
 * @author WilliamFritzen
 */
public class StudentTableModel {

    private String[] columnNames = {"id", "fName", "lName", "address", "phone", "email", "birthday"};

    private ArrayList<Student> studentlist;

    public StudentTableModel(ArrayList<Student> studentlist) {
        this.studentlist = studentlist;
    }

    public int getColumnCount() {
        return columnNames.length;
    }

    public int getRowCount() {
        return studentlist.size();
    }

    public String getColumnName(int col) {
        return columnNames[col];
    }

    public Object getValueAt(int row, int col) {

        Object o = null;
        switch (col) {
            case 0:
                o = studentlist.get(row).getId();
                break;
            case 1:
                o = studentlist.get(row).getFirstName();
                break;
            case 2:
                o = studentlist.get(row).getLastName();
                break;
            case 3:
                o = studentlist.get(row).getEmail();
                break;
            case 4:
                o = studentlist.get(row).getPhone();
                break;
            case 5:
                o = studentlist.get(row).getBirthday();
                break;

        }

        return o;

    }
}
