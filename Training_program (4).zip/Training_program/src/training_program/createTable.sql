/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Mohammed
 * Created: 26-03-2017
 */

CREATE TABLE "student" 
( 
"id" INT not null primary key
        GENERATED ALWAYS AS IDENTITY
        (START WITH 1, INCREMENT BY 1),   
"fName" VARCHAR(30),     
"lName" VARCHAR(30),
"address" VARCHAR(30),
"phone" VARCHAR(20),
"email" VARCHAR(20),
"birthday" VARCHAR(20)

);

CREATE TABLE "teacher" 
( 
"id" INT not null primary key
        GENERATED ALWAYS AS IDENTITY
        (START WITH 1, INCREMENT BY 1),   
"name" VARCHAR(30),     
"email" VARCHAR(30),
"phone" VARCHAR(30)

);

CREATE TABLE "course" 
( 
"id" INT not null primary key
        GENERATED ALWAYS AS IDENTITY
        (START WITH 1, INCREMENT BY 1),   
"courseName" VARCHAR(30)  

);
