package training_program.Controller;

import java.util.ArrayList;
import training_program.Model.StudentMapper;
import training_program.Model.Student;

/**
 *
 * @author grama
 */
public class StudentController {
   
    private StudentMapper studentMapper;
    
    public StudentController() {

    studentMapper = new StudentMapper();
}
 

    public ArrayList<Student> getStudentList() {
        return studentMapper.getAllStudents();
    }

    public Student getStudent(String searchname) {
        return studentMapper.getStudent(searchname);
    }
   
    
    public void createStudent(Student s){
    
    studentMapper.insertNewStudent(s);
    }
   public void updateStudent(Student s)
    {
       studentMapper.updateStudent(s);

    }
   public void deleteStudent(int id)
    {
       studentMapper.deleteStudent(id);

    }

     
    
}